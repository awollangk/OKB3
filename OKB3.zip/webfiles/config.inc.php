<?php
//Your mysql host
$dbhost = 'localhost';
//Your mysql user
$dbuser = 'root';
//Your mysql password
$dbpass = 'password';
//Your mysql database
$dbname = 'dbname';
//Your custom password. #####THIS MUST MATCH THE PHP PASSWORD IN CONFIG.YML!#####
$phppass = '12345pass';
//The prefix used by your forum tables. Let's say your table your usernames are stored in
// is called 'phpbb_users'...in this case the prefix is 'phpbb_'. set to $sqlprefix = ''; for no prefix.
$sqlprefix = 'prefix_';
?>